///////////////////////////////////////////////////
// ContactService class
// @author Shawn Way
//
// Manage the storage of Contact objects
///////////////////////////////////////////////////

package contact;

import java.util.ArrayList;

public class ContactService {
	
	private int lastID = 0;
	
	public void addContact(ArrayList<Contact> contactList, String firstName, String lastName, String phone, String address) {
		lastID = lastID + 1;
		String id = String.valueOf(lastID);
		Contact newContact = new Contact(id, firstName, lastName, phone, address);
		contactList.add(newContact);
	}
	
	public void deleteContact(ArrayList<Contact> contactList, String id) {
		int removeIndex = -1;
		
		for (Contact checkContact : contactList) {
			if (checkContact.getId().equals(id)) {
				removeIndex = contactList.indexOf(checkContact);
			}
		}
		
		if (removeIndex >= 0) {
			contactList.remove(removeIndex);
		}
	}
	
	public void updateFirstName(ArrayList<Contact> contactList, String id, String firstNameIn) {
		for (Contact checkContact : contactList) {
			if (checkContact.getId().equals(id)) {
				checkContact.setFirstName(firstNameIn);
			}
		}
	}
	
	public void updateLastName(ArrayList<Contact> contactList, String id, String lastNameIn) {
		for (Contact checkContact : contactList) {
			if (checkContact.getId().equals(id)) {
				checkContact.setLastName(lastNameIn);
			}
		}
	}
	
	public void updatePhone(ArrayList<Contact> contactList, String id, String phoneIn) {
		for (Contact checkContact : contactList) {
			if (checkContact.getId().equals(id)) {
				checkContact.setPhone(phoneIn);
			}
		}
	}
	
	public void updateAddress(ArrayList<Contact> contactList, String id, String addressIn) {
		for (Contact checkContact : contactList) {
			if (checkContact.getId().equals(id)) {
				checkContact.setAddress(addressIn);
			}
		}
	}
}
