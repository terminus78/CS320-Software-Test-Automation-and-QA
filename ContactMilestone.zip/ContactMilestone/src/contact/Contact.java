///////////////////////////////////////////////////
// Contact class
// @author Shawn Way
//
// Create objects to hold contact information
///////////////////////////////////////////////////

package contact;

public class Contact {
	
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String idIn, String firstNameIn, String lastNameIn, String phoneIn, String addressIn) {
		Contact.verify("ID", 10, false, idIn);
		Contact.verify("First name", 10, false, firstNameIn);
		Contact.verify("Last name", 10, false, lastNameIn);
		Contact.verify("Phone number", 10, true, phoneIn);
		Contact.verify("Address", 30, false, addressIn);
		
		id = idIn;
		firstName = firstNameIn;
		lastName = lastNameIn;
		phone = phoneIn;
		address = addressIn;
	}
	
	public String getId() {
		return id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstNameIn) {
		Contact.verify("First name", 10, false, firstNameIn);
		firstName = firstNameIn;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastNameIn) {
		Contact.verify("Last name", 10, false, lastNameIn);
		lastName = lastNameIn;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phoneIn) {
		Contact.verify("Phone number", 10, true, phoneIn);
		phone = phoneIn;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String addressIn) {
		Contact.verify("Address", 30, false, addressIn);
		address = addressIn;
	}
	
	// Parameter length and non-null verification
	private static void verify(String paramName, int numOfChar, boolean mustBeExact, String paramValue) {
		if (paramValue == null) {
			throw new IllegalArgumentException(paramName + " cannot be null!");
		}
		else if (mustBeExact) {
			if (paramValue.length() != numOfChar) {
				throw new IllegalArgumentException(paramName + " must be exactly " + numOfChar + " characters!");
			}
		}
		else {
			if (paramValue.length() > numOfChar) {
				throw new IllegalArgumentException(paramName + " cannot be more than " + numOfChar + " characters!");
			}
		}
	}
}
