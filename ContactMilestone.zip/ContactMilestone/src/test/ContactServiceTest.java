///////////////////////////////////////////////////
// ContactServiceTest test class
// @author Shawn Way
//
// JUnit automated test of ContactService class
///////////////////////////////////////////////////

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import contact.Contact;
import contact.ContactService;

class ContactServiceTest {
	
	// Test adding a contact
	@Test
	void testAddContact() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		
		assertTrue(contactList.get(0).getFirstName().equals("John"));
	}
	
	// Test deleting a contact
	@Test
	void testDeleteContact() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		testService.addContact(contactList, "Brawn", "Myth", "5557654321", "124 Notta Rd. Nowhere, State");
		testService.addContact(contactList, "Fawn", "Synth", "5550101010", "125 Notta Rd. Nowhere, State");
		testService.deleteContact(contactList, "3");
		
		Assertions.assertThrows(IndexOutOfBoundsException.class, () -> {contactList.get(2);});
	}
	
	// Tests for updating contact information
	@Test
	void testUpdateContactFirstName() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		testService.updateFirstName(contactList, "1", "Brawn");
		
		assertTrue(contactList.get(0).getFirstName().equals("Brawn"));
	}
	
	@Test
	void testUpdateContactLastName() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		testService.updateLastName(contactList, "1", "Myth");
		
		assertTrue(contactList.get(0).getLastName().equals("Myth"));
	}
	
	@Test
	void testUpdateContactPhone() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		testService.updatePhone(contactList, "1", "5557654321");
		
		assertTrue(contactList.get(0).getPhone().equals("5557654321"));
	}
	
	@Test
	void testUpdateContactAddress() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		ContactService testService = new ContactService();
		testService.addContact(contactList, "John", "Smith", "5551234567", "123 Notta Rd. Nowhere, State");
		testService.updateAddress(contactList, "1", "124 Notta Rd. Nowhere, State");
		
		assertTrue(contactList.get(0).getAddress().equals("124 Notta Rd. Nowhere, State"));
	}
}
