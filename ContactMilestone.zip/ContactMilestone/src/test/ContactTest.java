///////////////////////////////////////////////////
// ContactTest test class
// @author Shawn Way
//
// JUnit automated test of Contact class
///////////////////////////////////////////////////

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {
	
	// Test parameter equality
	@Test
	void testContactParameters() {
		Contact testContact = new Contact(
					"1",
					"John",
					"Smith",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		assertTrue(testContact.getId().equals("1"));
		assertTrue(testContact.getFirstName().equals("John"));
		assertTrue(testContact.getLastName().equals("Smith"));
		assertTrue(testContact.getPhone().equals("5551234567"));
		assertTrue(testContact.getAddress().equals("123 Notta Rd. Nowhere, State"));
	}
	
	// Test parameter length validation
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"12345678901",
					"John",
					"Smith",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"Johnathania",
					"Smith",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smithamanic",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smith",
					"55512345678",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smith",
					"555123456",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smith",
					"55512345678",
					"123 Nottadam Rd. Nowhere, State"
				);
		});
	}
	
	// Test requirement to disallow null values
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					null,
					"John",
					"Smith",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					null,
					"Smith",
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					null,
					"5551234567",
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smith",
					null,
					"123 Notta Rd. Nowhere, State"
				);
		});
	}
	
	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"1",
					"John",
					"Smith",
					"5551234567",
					null
				);
		});
	}
}
